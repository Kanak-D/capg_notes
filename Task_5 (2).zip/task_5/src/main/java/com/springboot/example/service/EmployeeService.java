package com.springboot.example.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springboot.example.entity.Employee;
import com.springboot.example.repository.EmployeeRepository;

@Service
public class EmployeeService {
	
	@Autowired
	private EmployeeRepository repository;
	
	public Employee saveEmployee(Employee employee)
	{
		return repository.save(employee);
	}
	public List<Employee> saveEmployees(List<Employee> employees)
	{
		return repository.saveAll(employees);
	}
	public List<Employee> getEmployees()
	{
		return repository.findAll(); 
	}
	public Employee getEmployeeById(int employee_id)
	{
		return repository.findById(employee_id).orElse(null);
	}

}
