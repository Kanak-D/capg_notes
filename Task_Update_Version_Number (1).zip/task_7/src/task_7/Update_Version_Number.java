package task_7;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;


public class Update_Version_Number {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String[] filePaths =
			{
					"C:\\Users\\KDHAKARI\\eclipse-workspace\\task_7\\src\\task_7\\file1.txt",
					"C:\\Users\\KDHAKARI\\eclipse-workspace\\task_7\\src\\task_7\\file2.txt",
					"C:\\Users\\KDHAKARI\\eclipse-workspace\\task_7\\src\\task_7\\file3.txt",
					"C:\\Users\\KDHAKARI\\eclipse-workspace\\task_7\\src\\task_7\\file4.txt",
					"C:\\Users\\KDHAKARI\\eclipse-workspace\\task_7\\src\\task_7\\file5.txt",
					"C:\\Users\\KDHAKARI\\eclipse-workspace\\task_7\\src\\task_7\\file6.txt",
					"C:\\Users\\KDHAKARI\\eclipse-workspace\\task_7\\src\\task_7\\file7.txt",
					"C:\\Users\\KDHAKARI\\eclipse-workspace\\task_7\\src\\task_7\\file8.txt",
					"C:\\Users\\KDHAKARI\\eclipse-workspace\\task_7\\src\\task_7\\file9.txt",
					"C:\\Users\\KDHAKARI\\eclipse-workspace\\task_7\\src\\task_7\\file10.txt",
					
			};
		String oldVersion="10.1";
		String newVersion="10.2";
		for(String filePath:filePaths)
		{
			updateVersion(filePath,oldVersion,newVersion);
		}

	}
	public static void updateVersion(String filePath,String oldVersion,String newVersion)
	{
		try
		{
			BufferedReader reader = new BufferedReader(new FileReader(filePath));
			String line;
			StringBuilder content = new StringBuilder();
			while((line=reader.readLine())!=null)
			{
				content.append(line).append(System.lineSeparator());
				
			}
			reader.close();
			String fileContent= content.toString();
			String updatedContent=fileContent.replace(oldVersion,newVersion);
			BufferedWriter writer = new BufferedWriter(new FileWriter(filePath));
			writer.write(updatedContent);
			writer.close();
			System.out.println("Version updated successfully in: "+filePath);
			
			
			
		}
		catch(IOException e)
		{
			System.out.println("Error occured while updating the version in: "+filePath);
			e.printStackTrace();
		}
	}

}
