package com.springboot.example;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Task5ApplicationTests {

	@Test
	void contextLoads() {
	}

}
