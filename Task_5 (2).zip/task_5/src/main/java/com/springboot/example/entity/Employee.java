package com.springboot.example.entity;
import jakarta.persistence.Column;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Entity
@Data
@Table(name="employee")
@NoArgsConstructor
@AllArgsConstructor
public class Employee {
	
	 
	
		@Id
		
		@GeneratedValue
		private int employee_id;
		
		private String first_name;
		
		private String second_name;
	
		private int age;
		
		private String gender;
		
		private String qualification;

	
}
