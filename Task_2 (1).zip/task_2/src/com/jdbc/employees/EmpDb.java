package com.jdbc.employees;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;


public class EmpDb {

	public static void main(String[] args) {
		Connection conn = null;	
	   Scanner scanner = new Scanner(System.in);
			
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			String dbUrl ="jdbc:mysql://localhost:3306/test";
			String username="root";
			String password ="Radhe@1940";

			conn = DriverManager.getConnection(dbUrl,username,password);
			System.out.println("Enter Unique Employee Id");
			
			int id = Integer.parseInt(scanner.nextLine());
			String sql = "select * from employees where employee_id = "+id;
			Statement statement = conn.createStatement();
			ResultSet result = statement.executeQuery(sql);
			while(result.next())
			{
				int id_ = result.getInt("employee_id");
				String fn_ = result.getString("first_name");
				String ln_ = result.getString("last_name");
				int age_ = result.getInt("age");
				String g_= result.getString("gender");
				
				System.out.println("Employee Id:"+id_);
				System.out.println("First Name:"+fn_);
				System.out.println("Last Name:"+ln_);
				System.out.println("Age:"+age_);
				System.out.println("Gender:"+g_);
				
				
			}
			
			conn.close();
			scanner.close();
			
			
		} catch (SQLException | ClassNotFoundException e) {
			System.out.println(e);
		}
		

	}

}
