/**
 * 
 */
/**
 * @author kdhakari
 *
 */
module task_2 {
	requires java.sql;
}