/**
 * 
 */
/**
 * @author kdhakari
 *
 */
module task_7 {
}